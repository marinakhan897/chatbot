# c3c-fbstate
A Chrome extension. Used to import/export fbstate.json file to be used with C3C or any other bots based on fca-unofficial/facebook-chat-api.

See how to install this thing: https://www.youtube.com/embed/KN6UzbisSFo
